/* LAB 7 - SHIPPING FORM */
//Order Shipping object (for extra EXTRA challenge, otherwise, ignore it)

var shipInfo = {
	cid: 0,
	name: "",
	pc: "",
	speed: "",
	cost: 0
};

window.onload = function() {
	var formHandle = document.forms.form_ship;
	formHandle.onsubmit = processForm;
	console.log(formHandle);
	

	function processForm() {
		//alert("Form sent"); 
		var hideForm = document.getElementById("shippingForm");
	
		var nameValue = formHandle.f_Name;
		console.log(nameValue);
		console.log(nameValue.value);
		var CustomerName= document.getElementById("thanksCustomer");
		CustomerName.innerHTML= nameValue.value;
		
	
		var postcodeValue = formHandle.f_pc;
		console.log(postcodeValue);
		console.log(postcodeValue.value);
		var customerPost = document.getElementById("thanksPC");
		customerPost.innerHTML = postcodeValue.value;
		
		if (nameValue.value === "") {
			
			nameValue.style.background = "red";
		
			return false;
		}

		if (postcodeValue.value === "") {
	
			postcodeValue.style.background = "red";
			
			return false;
		}
		hideForm.style.display="none";
	
		var tksform = document.getElementById("thanks_msg");
		tksform.style.display="block";
		
		
		return false;
			
		
	}
	
}
	
